﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace Services
{
    public class ShoppingService
    {
        private readonly ECommerceDbContext _dbContext;
        public ShoppingService(ECommerceDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public List<Item> GetItems()
        {
            return _dbContext.Items.ToList();
        }
        public Item AddItem(Item item)
        {
            var addedItem = _dbContext.Items.Add(item);

            _dbContext.SaveChanges();

            return addedItem.Entity;
        }
        public Item DeleteItem(int id)
        {
            var itemInDb = _dbContext.Items.FirstOrDefault(x => x.Id == id);

            if (itemInDb != null)
            {
                _dbContext.Items.Remove(itemInDb);
            }

            _dbContext.SaveChanges();

            return itemInDb;
        }
        public List<Item> GetItemsAbovePrice(float price) =>
            _dbContext.Items.Where(item => item.Price > price).ToList();

    }
}
