﻿using Microsoft.AspNetCore.Mvc;
using Services;
using Domain;


namespace ECoApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingController : ControllerBase
    {
        public ShoppingService _shoppingService;
        public ShoppingController(ShoppingService shoppingService)
        {
            _shoppingService = shoppingService;
        }

        [HttpGet("GetItems")]
        public List<Item> GetItems()
        {
            var items = _shoppingService.GetItems();

            return items;
        }

        [HttpPost("AddItem")]
        public Item AddItem(Item item)
        {
            var addedItem = _shoppingService.AddItem(item);

            return addedItem;
        }

        [HttpDelete("DeleteItem")]
        public Item DeleteItem(int id)
        {
            var deletedItem = _shoppingService.DeleteItem(id);

            return deletedItem;
        }

        [HttpPost("GetItemsAbovePrice")]
        public List<Item> GetItemsAbovePrice(float price)
        {
            var items = _shoppingService.GetItemsAbovePrice(price);

            return items;
        }

    }
}
